
 ***********************************************
 *                 *** ABOUT ***               * 
 *                                             *
 * name:           Russian checkers            *
 * author:         Evgeniy Korniloff           *
 * ver:            2.2x                        *
 * date:           2005-2022                   *
 * system:         Windows, Linux & wine       *
 *                                             *
 ***********************************************

  run:
    echoboard.exe

   
------------------------------------------------   

                 *** FILES ***

            
rcheckrs.exe     -   checkers engine, text-mode, WINDOWS
echoboard.exe    -   simple graph. shell,        WINDOWS





------------------------------------------------


                 *** COPYRIGHT(C) ***
                 
   copyright(c):   free ware
   
   


   
-------------------------------------------------

                *** CONTACT ***
 
   mail:           evgeniy-korniloff@yandex.ru
                   
                 



